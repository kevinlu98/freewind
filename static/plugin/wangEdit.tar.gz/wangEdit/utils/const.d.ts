/**
 * @description 常量
 * @author wangfupeng
 */
export declare function EMPTY_FN(): void;
export declare const urlRegex: RegExp;
