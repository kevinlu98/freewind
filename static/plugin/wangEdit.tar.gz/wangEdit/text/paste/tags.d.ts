/**
 * @description 粘贴相关的 tags
 * @author wangfupeng
 */
export declare const IGNORE_TAGS: Set<string>;
export declare const NECESSARY_ATTRS: Map<string, string[]>;
export declare const EMPTY_TAGS: Set<string>;
export declare const TOP_LEVEL_TAGS: Set<string>;
