import Editor from '../../../editor/index';
declare function bindEvent(editor: Editor): void;
export default bindEvent;
