/**
 * @description 拖拽上传图片
 * @author wangfupeng
 */
import Editor from '../../../editor/index';
export default function bindDropImg(editor: Editor): void;
