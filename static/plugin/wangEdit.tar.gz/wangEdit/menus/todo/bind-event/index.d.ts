import Editor from '../../../editor/index';
/**
 * todolist 内部逻辑
 * @param editor
 */
declare function bindEvent(editor: Editor): void;
export default bindEvent;
