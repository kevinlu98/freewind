import Editor from '../../../editor/index';
export default function bindTooltipEvent(editor: Editor): void;
