/**
 * @description 检查选区是否在代码中，即菜单是否应该 active
 * @author lkw
 */
import Editor from '../../editor/index';
declare function isActive(editor: Editor): boolean;
export default isActive;
