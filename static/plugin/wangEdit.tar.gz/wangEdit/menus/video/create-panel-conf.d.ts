/**
 * @description video 菜单 panel tab 配置
 * @author tonghan
 */
import Editor from '../../editor/index';
import { PanelConf } from '../menu-constructors/Panel';
export default function (editor: Editor, video: string): PanelConf;
