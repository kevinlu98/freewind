/**
 * @description 初始化编辑器 DOM 结构
 * @author wangfupeng
 */
import Editor from '../index';
export default function (editor: Editor): void;
